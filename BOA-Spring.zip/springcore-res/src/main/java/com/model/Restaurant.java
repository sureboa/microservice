package com.model;

public interface Restaurant {
	
	public String prepareDish(String dishName);

}
