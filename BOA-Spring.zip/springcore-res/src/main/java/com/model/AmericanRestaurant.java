package com.model;

public class AmericanRestaurant implements Restaurant{

	@Override
	public String prepareDish(String dishName) {
		// TODO Auto-generated method stub
		return "Preparing " + dishName + " with buns spices and sauces";
	}
}
