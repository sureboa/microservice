package com.service;

import com.model.InterestCalculator;

public class BankingService {
	
	private InterestCalculator ic;

	
	
	public BankingService(InterestCalculator ic) {
		super();
		this.ic = ic;
	}



	public double calculateApp(double amount) {
		return ic.calculate(amount);
	}

}
