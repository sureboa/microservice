package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.BankingService;

public class BankingClient {
	
	public static void main(String[] args) {
		//step-1 initalize the container
		// load all the beans and instantiate it eager
		ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		//load the service class
		BankingService bs=(BankingService)ctx.getBean("service");
		BankingService bs2=(BankingService)ctx.getBean("service");
		//System.out.println(bs.calculateApp(2345));
		System.out.println(bs.hashCode());
		System.out.println(bs2.hashCode());

	}

}
