package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.BankingService;

public class BankingClient {
	
	public static void main(String[] args) {
 
		 
		ConfigurableApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		 
		BankingService bs=(BankingService)ctx.getBean("service");
	 
		System.out.println(bs.calculateApp(2345));
		 
ctx.close();
	}

}
