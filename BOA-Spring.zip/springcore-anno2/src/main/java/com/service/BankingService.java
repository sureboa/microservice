package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;
 public class BankingService {
	
	 
	private InterestCalculator ic;
 
	public BankingService(InterestCalculator ic) {
		super();
		this.ic = ic;
	}

	public double calculateApp(double amount) {
		return ic.calculate(amount);
	}
	@PostConstruct
	public void init() {
		System.out.println("inside INIT");
	}
	@PreDestroy
	public void destroy() {
		System.out.println("service destroyed");
	}

}
