package com.client;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import com.model.FixedAccount;
import com.model.SavingAccount;
import com.service.BankingService;

@Configuration
@ComponentScan("com")
public class AppConfig {
	@Bean
	public SavingAccount sa() {
		return new SavingAccount(4,4.5);
	}
	@Bean
	@Lazy
	public FixedAccount fda() {
		return new FixedAccount();
	}
	@Bean
	public BankingService service() {
		return new BankingService(sa());
	}


}
