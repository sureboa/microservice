package com.delegate;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

 
@Service
public class AppDelegate {
	
	RestTemplate template= new RestTemplate();
	
	public String callService() {
		String response=template.exchange(
				"http://localhost:8090/mainapp/loadusers",
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
		return response;
		
	}

}
