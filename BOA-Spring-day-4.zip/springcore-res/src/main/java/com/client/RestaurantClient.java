package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.RestaurantService;

 
public class RestaurantClient {
	
	public static void main(String[] args) {
	 
		ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		 
		RestaurantService rs=(RestaurantService)ctx.getBean("service");
		
		System.out.println(rs.takeOrder("pancakes"));

	}

}
