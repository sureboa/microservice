package com.service;

import com.model.Restaurant;

public class RestaurantService {
	
	
	private Restaurant restaurant;

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	
	public String takeOrder(String order) {
		return restaurant.prepareDish(order);
	}

}
