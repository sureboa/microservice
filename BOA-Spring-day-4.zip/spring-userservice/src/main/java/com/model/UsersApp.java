package com.model;

import java.util.ArrayList;
import java.util.List;

public class UsersApp {
	
	private List<Users> user;

	public List<Users> getUser() {
		if(user==null) {
			user= new ArrayList<Users>();
			return user;
		}
		return user;
	}

	public void setUser(List<Users> user) {
		this.user = user;
	}
	
	

}
