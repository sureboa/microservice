package com.service;

import java.util.List;

import com.model.Users;
import com.model.UsersApp;

public interface UserServices {
	
	public UsersApp getAll();
public  void addUser(Users user);

}
