package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Users;
import com.model.UsersApp;

@Service
public class UserServiceImpl implements UserServices {
	private static UsersApp list= new UsersApp();
	
	static {
		list.getUser().add(new Users("admin", "admin@123", "admin@mail.com", "delhi"));
		list.getUser().add(new Users("manager", "manager@123", "manager@mail.com", "chennai"));
		list.getUser().add(new Users("QA", "qa@123", "qa@mail.com", "hyderabad"));
	}

	@Override
	public UsersApp getAll() {
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public void addUser(Users user) {
		list.getUser().add(user);
		
	}

	
}
