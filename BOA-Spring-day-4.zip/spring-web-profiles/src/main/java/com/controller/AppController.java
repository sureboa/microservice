package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Users;
import com.service.UserServices;

@RestController
@RequestMapping("/mainapp")
public class AppController {
	@Autowired
	private UserServices services;

	@PostMapping("/login")
	public String loginValid(@RequestBody Users user) {
		if (services.loginValid(user.getUname(), user.getPass())) {
			return "login success";
		}
		return "login failed";
	}

	@PostMapping("/register")
	public String registerUser(@RequestBody Users user) {

		services.registerUser(user);
		return "user registered";
	}
	@GetMapping("/loadall")
	public List<Users>loadAll(){
		return services.loadUsers();
	}
	@GetMapping("/finduser/{uname}")
	public String findUser(@PathVariable String uname) {
		if(services.findUser(uname)) {
			return uname + " found and available";
		}
		return "user not found....!";
	}
	@DeleteMapping("/deleteuser/{uname}")
	public String deleteUser(@PathVariable String uname) {
		if(services.deleteUser(uname)) {
			return uname + " found and deleted";
		}
		return "user not found....!";
	}
	
	@PutMapping("/updateuser/{uname}")
	public String updateUser(@PathVariable String uname,@RequestBody Users user) {
		services.updateUser(uname,user);  
		return "user found.... and updated!";
	}
	
	
	
	
	
}
