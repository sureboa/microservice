package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Users;

@Service
public class UserServiceImpl implements UserServices {

	ArrayList<Users> al = new ArrayList<Users>();

	@Override
	public boolean loginValid(String uname, String pass) {
		if (uname.equals("admin") && pass.equals("manager")) {
			return true;
		}
		return false;

	}

	@Override
	public void registerUser(Users users) {
		al.add(users);
		System.out.println(al);

	}

	@Override
	public List<Users> loadUsers() {

		return al;
	}

	@Override
	public boolean findUser(String name) {
		 for(Users user:al) {
			 if(user.getUname().equals(name)) {
				 System.out.println(user.getEmail());
				 return true;
			 }
		 }
		return false;
	}

	@Override
	public boolean deleteUser(String name) {
		 for(Users user:al) {
			 if(user.getUname().equals(name)) {
				 al.remove(user);
				 return true;
			 }
		 }
		return false;
	}

	@Override
	public void updateUser(String name, Users user) {
		 
		 for(Users userdata:al) {
			 if(userdata.getUname().equals(name)) {
				 
				 // put your code here......
			 }
		 }
	 
	}
}
