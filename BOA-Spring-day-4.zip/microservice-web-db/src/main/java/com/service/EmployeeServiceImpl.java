package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Employee;
import com.repo.EmployeeRepo;
@Service
public class EmployeeServiceImpl implements EmpService {
	
	@Autowired
	private EmployeeRepo repo;

	@Override
	public void addEmployee(Employee emp) {
		 
		repo.save(emp);
		
	}

	@Override
	public List<Employee> loadall() {
		// TODO Auto-generated method stub
		
		return (List<Employee>)repo.findAll();
		
	}

	@Override
	public boolean findEmp(int empno) {
	 
		Optional<Employee> op= repo.findById(empno);
		if(op.isPresent()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteEmp(int empno) {
		Optional<Employee> op= repo.findById(empno);
		if(op.isPresent()) {
			repo.deleteById(empno);
			return true;
		}
		return false;
	}

	@Override
	public void updateEmp(int empno, String empname) {
		 repo.updateEmp(empname, empno);
		
	}
	

}
