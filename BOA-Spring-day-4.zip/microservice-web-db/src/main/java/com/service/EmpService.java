package com.service;

import java.util.List;

import com.entity.Employee;

public interface EmpService {
	
	public void addEmployee(Employee emp);
	public List<Employee>loadall();
	public boolean findEmp(int empno);
	public boolean deleteEmp(int empno);
	public void updateEmp(int empno,String empname);

}
