package com.example.springwebdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
